# WeChatContacts
实现微信通讯录UI，联系人按拼音首字母分组排序A~Z，并且含联系人搜索功能。后续持续更新。。。。。。

##效果图
  ![image](https://github.com/shenAlexy/WeChatContacts/blob/master/WeChatContacts-demo/WeChatContacts-demo/x.png) ![image](https://github.com/shenAlexy/WeChatContacts/blob/master/WeChatContacts-demo/WeChatContacts-demo/y.png) ![image](https://github.com/shenAlexy/WeChatContacts/blob/master/WeChatContacts-demo/WeChatContacts-demo/z.png)

#联系我
   微信公众号:  iOSDevTeam
   
   Email: shenguanhua123@gmail.com
   
   [我的博客](http://blog.csdn.net/shenguanhua) 

